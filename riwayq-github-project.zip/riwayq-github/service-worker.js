const CACHE_NAME = "riwayq-v2";
const APP_SHELL = [
  "./",
  "./index.html",
  "./style.css",
  "./app.js",
  "./mutun.json",
  "./manifest.webmanifest",
  "./offline.html",
  "./icons/icon.svg"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter(key => key.startsWith("riwayq-") && key !== CACHE_NAME)
      .map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response.ok) {
          const cache = await caches.open(CACHE_NAME);
          cache.put("./index.html", response.clone());
        }
        return response;
      } catch {
        return (await caches.match(request)) ||
               (await caches.match("./index.html")) ||
               (await caches.match("./offline.html"));
      }
    })());
    return;
  }

  const networkUpdate = fetch(request).then(async response => {
    if (response && response.ok) {
      const cache = await caches.open(CACHE_NAME);
      await cache.put(request, response.clone());
    }
    return response;
  });

  // Start the refresh while the fetch event is active; serve cached data first.
  event.waitUntil(networkUpdate.then(() => undefined).catch(() => undefined));
  event.respondWith(caches.match(request).then(cached => {
    if (cached) return cached;
    return networkUpdate.catch(async () =>
      (await caches.match("./offline.html")) ||
      new Response("أنت غير متصل بالإنترنت.", {
        status: 503,
        headers: {"Content-Type":"text/plain; charset=utf-8"}
      })
    );
  }));
});
