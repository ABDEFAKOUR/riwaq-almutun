"use strict";
const STORAGE_KEY = "riwayq-progress-v2";
let library = [];
let progress = loadProgress();
let currentMatn = null;
let currentItems = [];
let currentIndex = 0;
let textHidden = false;
let installPrompt = null;
const $ = (selector) => document.querySelector(selector);

function loadProgress() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; }
  catch { return {}; }
}
function saveProgress() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  renderStats();
}
function toast(message) {
  const el = $("#toast");
  if (!el) return;
  el.textContent = message;
  el.classList.add("show");
  window.setTimeout(() => el.classList.remove("show"), 2300);
}
function normalizeMatn(matn) {
  const items = Array.isArray(matn.passages) ? matn.passages : (Array.isArray(matn.items) ? matn.items : []);
  return {...matn, passages: items.map((item, i) => ({
    id: item.id || `${matn.id}-item-${i+1}`,
    reference: item.reference || item.chapter || `المقطع ${i+1}`,
    text: item.text || "",
    note: item.note || ""
  }))};
}
function renderStats() {
  const values = Object.values(progress);
  $("#statDone").textContent = values.filter(x => x.status === "mastered").length;
  $("#statLearning").textContent = values.filter(x => x.status === "learning").length;
  $("#statDue").textContent = values.filter(x => x.status !== "mastered" && x.dueAt && x.dueAt <= Date.now()).length;
}
function renderMatns() {
  const q = $("#searchInput").value.trim().toLocaleLowerCase();
  const level = $("#levelFilter").value;
  const items = library.filter(m => {
    const matchesQuery = `${m.title} ${m.author} ${m.subject || ""}`.toLocaleLowerCase().includes(q);
    return matchesQuery && (level === "all" || String(m.level) === level);
  });
  $("#matnList").innerHTML = items.length ? items.map(m => `
    <button class="matn-card" type="button" data-id="${escapeAttr(m.id)}">
      <span><h3>${escapeHtml(m.title)}</h3><p>${escapeHtml(m.author || "مؤلف غير محدد")} · المستوى ${m.level || "—"} · ${m.passages.length} مقطع</p>
      <span class="description">${escapeHtml(m.description || m.subject || "")}</span></span><span class="matn-arrow">←</span>
    </button>`).join("") : `<p class="muted">لا توجد نتائج مطابقة.</p>`;
  $("#matnList").querySelectorAll(".matn-card").forEach(btn => btn.addEventListener("click", () => openMatn(btn.dataset.id)));
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function escapeAttr(value) { return escapeHtml(value); }
function showView(name) {
  document.querySelectorAll(".view").forEach(v => v.classList.add("hidden"));
  $(`#${name}View`).classList.remove("hidden");
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.view === name));
  if (name === "review") renderReview();
  if (name === "similar") renderSimilar();
}
function openMatn(id) {
  currentMatn = library.find(m => m.id === id);
  if (!currentMatn) return;
  currentItems = currentMatn.passages;
  currentIndex = 0;
  $("#readerTitle").textContent = currentMatn.title;
  $("#readerDescription").textContent = currentMatn.description || `${currentMatn.author || ""} · ${currentMatn.subject || ""}`;
  renderChapters();
  showView("reader");
  if (currentItems.length) showItem(0);
  else $("#versePanel").classList.add("hidden");
}
function renderChapters() {
  const chapters = [...new Set(currentItems.map(x => x.reference))];
  $("#chapterList").innerHTML = chapters.length ? chapters.map((name, i) => {
    const count = currentItems.filter(x => x.reference === name).length;
    return `<button class="chapter-card" type="button" data-reference="${escapeAttr(name)}">${escapeHtml(name)}<small>${count} مقطع</small></button>`;
  }).join("") : `<p class="muted">لا توجد مقاطع مدرجة لهذا المتن بعد.</p>`;
  $("#chapterList").querySelectorAll(".chapter-card").forEach(btn => btn.addEventListener("click", () => {
    const idx = currentItems.findIndex(x => x.reference === btn.dataset.reference);
    if (idx >= 0) showItem(idx);
  }));
}
function showItem(index) {
  if (!currentItems.length) return;
  currentIndex = Math.max(0, Math.min(index, currentItems.length - 1));
  const item = currentItems[currentIndex];
  textHidden = false;
  $("#versePanel").classList.remove("hidden");
  $("#verseCounter").textContent = `المقطع ${currentIndex + 1} من ${currentItems.length}`;
  $("#verseChapter").textContent = item.reference;
  $("#verseText").textContent = item.text;
  $("#verseText").classList.remove("blurred");
  $("#verseNote").textContent = item.note || "";
  $("#toggleCloze").textContent = "إخفاء النص";
  const mastered = progress[item.id]?.status === "mastered";
  $("#markLearned").textContent = mastered ? "✓ متقن" : "أتقنت هذا المقطع";
  $("#prevVerse").disabled = currentIndex === 0;
  $("#nextVerse").disabled = currentIndex === currentItems.length - 1;
}
function markLearned() {
  const item = currentItems[currentIndex];
  if (!item) return;
  progress[item.id] = {status:"mastered", dueAt:null, updatedAt:Date.now()};
  saveProgress(); showItem(currentIndex); toast("أحسنت! تم تسجيل إتقان المقطع.");
}
function scheduleReview(id) {
  progress[id] = {status:"review", dueAt:Date.now() + 24*60*60*1000, updatedAt:Date.now()};
  saveProgress();
}
function renderReview() {
  const due = [];
  library.forEach(m => m.passages.forEach(p => {
    const state = progress[p.id];
    if (state && state.status !== "mastered" && state.dueAt && state.dueAt <= Date.now()) due.push({matn:m, passage:p});
  }));
  $("#reviewCount").textContent = `${due.length} بطاقة`;
  $("#reviewPanel").innerHTML = due.length ? due.map(({matn,passage}) => `
    <article class="review-item"><b>${escapeHtml(matn.title)} — ${escapeHtml(passage.reference)}</b>
    <p>${escapeHtml(passage.text)}</p><button class="button button-primary" type="button" data-review="${escapeAttr(passage.id)}">تمت المراجعة</button></article>`).join("") : `<p>لا توجد مراجعات مستحقة الآن. أحسنت!</p>`;
  $("#reviewPanel").querySelectorAll("[data-review]").forEach(btn => btn.addEventListener("click", () => {
    const p = library.flatMap(m => m.passages).find(x => x.id === btn.dataset.review);
    if (!p) return;
    progress[p.id] = {status:"mastered", dueAt:null, updatedAt:Date.now()};
    saveProgress(); renderReview(); toast("تم تسجيل المراجعة.");
  }));
}
function renderSimilar() {
  const rows = [];
  library.forEach(m => (m.similar || []).forEach(s => rows.push({title:m.title, data:s})));
  $("#similarList").innerHTML = rows.length ? rows.map(x => `<article class="similar-item"><b>${escapeHtml(x.title)}</b><p>${escapeHtml(JSON.stringify(x.data))}</p></article>`).join("") : `<p class="muted">لا توجد مواضع متشابهات موثقة في البيانات الحالية.</p>`;
}
function exportProgress() {
  const blob = new Blob([JSON.stringify({app:"Riwayq", version:2, exportedAt:new Date().toISOString(), progress}, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = "riwayq-progress.json"; a.click();
  URL.revokeObjectURL(url); $("#backupMessage").textContent = "تم تنزيل نسخة التقدم.";
}
async function importProgress(file) {
  const data = JSON.parse(await file.text());
  if (!data.progress || typeof data.progress !== "object" || Array.isArray(data.progress)) throw new Error("ملف النسخة الاحتياطية غير صالح.");
  progress = data.progress; saveProgress(); $("#backupMessage").textContent = "تم استيراد تقدمك بنجاح.";
}
async function importMatn(file) {
  const data = JSON.parse(await file.text());
  const incoming = Array.isArray(data) ? data : [data];
  const normalized = incoming.map(normalizeMatn);
  const ids = new Set(library.map(m => m.id));
  normalized.forEach(m => { if (!m.id || !m.title || !Array.isArray(m.passages)) throw new Error("بنية ملف المتن غير مكتملة."); });
  library = [...library.filter(m => !normalized.some(n => n.id === m.id)), ...normalized];
  localStorage.setItem("riwayq-custom-mutun-v1", JSON.stringify(normalized));
  renderMatns(); toast("تم استيراد المتن في هذه الجلسة وحفظه على هذا الجهاز.");
}
async function init() {
  try {
    const response = await fetch("./mutun.json");
    if (!response.ok) throw new Error("HTTP " + response.status);
    library = (await response.json()).map(normalizeMatn);
    try {
      const custom = JSON.parse(localStorage.getItem("riwayq-custom-mutun-v1") || "[]");
      if (Array.isArray(custom)) custom.forEach(m => { library = library.filter(x => x.id !== m.id); library.push(normalizeMatn(m)); });
    } catch {}
    renderMatns(); renderStats(); renderReview(); renderSimilar();
  } catch (error) {
    $("#matnList").innerHTML = `<p class="muted">تعذر تحميل المكتبة. تأكد من تشغيل الموقع عبر localhost أو HTTPS، وأن ملف mutun.json موجود بجانب index.html.</p>`;
    console.error(error);
  }
}
document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => showView(tab.dataset.view)));
$("#searchInput").addEventListener("input", renderMatns);
$("#levelFilter").addEventListener("change", renderMatns);
$("#backLibrary").addEventListener("click", () => showView("library"));
$("#toggleCloze").addEventListener("click", () => {
  textHidden = !textHidden; $("#verseText").classList.toggle("blurred", textHidden);
  $("#toggleCloze").textContent = textHidden ? "إظهار النص" : "إخفاء النص";
});
$("#markLearned").addEventListener("click", markLearned);
$("#prevVerse").addEventListener("click", () => showItem(currentIndex - 1));
$("#nextVerse").addEventListener("click", () => showItem(currentIndex + 1));
$("#exportBtn").addEventListener("click", exportProgress);
$("#backupFile").addEventListener("change", async e => { try { if (e.target.files[0]) await importProgress(e.target.files[0]); } catch(err) { $("#backupMessage").textContent = err.message; } e.target.value = ""; });
$("#matnFile").addEventListener("change", async e => { try { if (e.target.files[0]) await importMatn(e.target.files[0]); } catch(err) { toast(err.message || "تعذر استيراد الملف."); } e.target.value = ""; });
function updateConnection() {
  const online = navigator.onLine;
  $("#connectionStatus").classList.toggle("offline", !online);
  $("#connectionStatus").innerHTML = `<i></i>${online ? "متصل" : "دون اتصال"}`;
}
window.addEventListener("online", updateConnection);
window.addEventListener("offline", updateConnection);
window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault(); installPrompt = event; $("#installBtn").classList.remove("hidden");
});
$("#installBtn").addEventListener("click", async () => {
  if (!installPrompt) return;
  installPrompt.prompt(); await installPrompt.userChoice;
  installPrompt = null; $("#installBtn").classList.add("hidden");
});
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js", {scope:"./"}).catch(err => console.error("Service Worker:", err)));
}
updateConnection();
init();
